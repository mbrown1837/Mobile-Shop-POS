<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-30 00:24:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\mobile-shop-pos\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-30 00:24:19 --> Unable to connect to the database
ERROR - 2025-12-30 00:24:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\mobile-shop-pos\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-30 00:24:30 --> Unable to connect to the database
ERROR - 2025-12-30 00:25:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\mobile-shop-pos\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-12-30 00:25:26 --> Unable to connect to the database
ERROR - 2025-12-30 00:54:27 --> Severity: Warning --> Undefined array key "pos_cart" C:\xampp\htdocs\mobile-shop-pos\application\libraries\Genlib.php 219
ERROR - 2025-12-30 00:54:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\mobile-shop-pos\application\libraries\Genlib.php 219
ERROR - 2025-12-30 13:09:54 --> Severity: error --> Exception: syntax error, unexpected variable "$this", expecting "function" or "const" C:\xampp\htdocs\mobile-shop-pos\application\controllers\Items.php 845
ERROR - 2025-12-30 13:09:55 --> Severity: error --> Exception: syntax error, unexpected variable "$this", expecting "function" or "const" C:\xampp\htdocs\mobile-shop-pos\application\controllers\Items.php 845
ERROR - 2025-12-30 13:09:55 --> Severity: error --> Exception: syntax error, unexpected variable "$this", expecting "function" or "const" C:\xampp\htdocs\mobile-shop-pos\application\controllers\Items.php 845
ERROR - 2025-12-30 13:09:55 --> Severity: error --> Exception: syntax error, unexpected variable "$this", expecting "function" or "const" C:\xampp\htdocs\mobile-shop-pos\application\controllers\Items.php 845
ERROR - 2025-12-30 13:09:55 --> Severity: error --> Exception: syntax error, unexpected variable "$this", expecting "function" or "const" C:\xampp\htdocs\mobile-shop-pos\application\controllers\Items.php 845
ERROR - 2025-12-30 23:42:59 --> Severity: Warning --> Undefined array key "pos_cart" C:\xampp\htdocs\mobile-shop-pos\application\libraries\Genlib.php 219
ERROR - 2025-12-30 23:42:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\mobile-shop-pos\application\libraries\Genlib.php 219
