<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-28 01:04:37 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:04:49 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:08:03 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:25:30 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:25:53 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:41:24 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:41:33 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:41:43 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:42:44 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:42:51 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:43:08 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:43:19 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:48:52 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:49:15 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:49:21 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mobile-shop-pos\application\controllers\Dashboard.php 162
ERROR - 2025-12-28 01:49:27 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mobile-shop-pos\application\controllers\Dashboard.php 162
ERROR - 2025-12-28 01:49:35 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mobile-shop-pos\application\controllers\Dashboard.php 162
ERROR - 2025-12-28 01:51:30 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:56:53 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:57:07 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:57:30 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:57:44 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:57:57 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:58:05 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 01:58:50 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:03:02 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:12:08 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:12:24 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:12:29 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:12:59 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:13:00 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:15:07 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:15:20 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:15:27 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:15:40 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:15:51 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:19:32 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:27:44 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:38:32 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:38:45 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:38:55 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:43:02 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:43:10 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:43:48 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:43:50 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 02:43:51 --> Query error: Unknown column 'last_seen' in 'field list' - Invalid query: UPDATE `admin` SET last_seen = NOW()
WHERE `id` = '1'
ERROR - 2025-12-28 03:54:58 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mobile-shop-pos\application\controllers\Dashboard.php 170
ERROR - 2025-12-28 04:05:42 --> Query error: Unknown column 'trade_in_value' in 'field list' - Invalid query: INSERT INTO `transactions` (transDate, `itemName`, `itemCode`, `description`, `quantity`, `unitPrice`, `totalPrice`, `totalMoneySpent`, `amountTendered`, `changeDue`, `modeOfPayment`, `transType`, `staffId`, `ref`, `vatAmount`, `vatPercentage`, `discount_amount`, `discount_percentage`, `cust_name`, `cust_phone`, `cust_email`, `profit_amount`, `payment_status`, `paid_amount`, `credit_amount`, `customer_id`, `trade_in_value`) VALUES (NOW(), 'Phone Case', 'ACC20241227004', '', '1', '500.00', 500, 500, '500.01', 0.0099999999999909, 'cash', 1, '1', '6807107', 0, 0, 0, 0, 'Hamid SHah', '03220716197', '', 150, 'paid', 500, 0, '6', 0)
ERROR - 2025-12-28 04:13:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 303
ERROR - 2025-12-28 04:13:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 328
ERROR - 2025-12-28 04:13:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 355
ERROR - 2025-12-28 04:13:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 365
ERROR - 2025-12-28 04:13:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 366
ERROR - 2025-12-28 04:13:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 367
ERROR - 2025-12-28 04:13:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 368
ERROR - 2025-12-28 04:13:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 426
ERROR - 2025-12-28 04:13:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\drivers\Session_files_driver.php 109
ERROR - 2025-12-28 04:13:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 110
ERROR - 2025-12-28 04:13:59 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 137
ERROR - 2025-12-28 04:13:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mobile-shop-pos\system\core\Exceptions.php:272) C:\xampp\htdocs\mobile-shop-pos\system\helpers\url_helper.php 565
ERROR - 2025-12-28 04:14:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 303
ERROR - 2025-12-28 04:14:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 328
ERROR - 2025-12-28 04:14:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 355
ERROR - 2025-12-28 04:14:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 365
ERROR - 2025-12-28 04:14:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 366
ERROR - 2025-12-28 04:14:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 367
ERROR - 2025-12-28 04:14:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 368
ERROR - 2025-12-28 04:14:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 426
ERROR - 2025-12-28 04:14:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\drivers\Session_files_driver.php 109
ERROR - 2025-12-28 04:14:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 110
ERROR - 2025-12-28 04:14:08 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\mobile-shop-pos\system\libraries\Session\Session.php 137
ERROR - 2025-12-28 04:14:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mobile-shop-pos\system\core\Exceptions.php:272) C:\xampp\htdocs\mobile-shop-pos\system\helpers\url_helper.php 565
ERROR - 2025-12-28 04:23:06 --> Query error: Unknown column 'trade_in_value' in 'field list' - Invalid query: INSERT INTO `transactions` (transDate, `itemName`, `itemCode`, `description`, `quantity`, `unitPrice`, `totalPrice`, `totalMoneySpent`, `amountTendered`, `changeDue`, `modeOfPayment`, `transType`, `staffId`, `ref`, `vatAmount`, `vatPercentage`, `discount_amount`, `discount_percentage`, `cust_name`, `cust_phone`, `cust_email`, `profit_amount`, `payment_status`, `paid_amount`, `credit_amount`, `customer_id`, `trade_in_value`) VALUES (NOW(), 'Phone Case', 'ACC20241227004', '', '1', '500.00', 500, 500, '500', 0, 'cash', 1, '1', '20421876', 0, 0, 0, 0, 'Hamid SHah', '03220716197', '', 150, 'paid', 500, 0, '6', 0)
ERROR - 2025-12-28 04:23:11 --> Query error: Unknown column 'trade_in_value' in 'field list' - Invalid query: INSERT INTO `transactions` (transDate, `itemName`, `itemCode`, `description`, `quantity`, `unitPrice`, `totalPrice`, `totalMoneySpent`, `amountTendered`, `changeDue`, `modeOfPayment`, `transType`, `staffId`, `ref`, `vatAmount`, `vatPercentage`, `discount_amount`, `discount_percentage`, `cust_name`, `cust_phone`, `cust_email`, `profit_amount`, `payment_status`, `paid_amount`, `credit_amount`, `customer_id`, `trade_in_value`) VALUES (NOW(), 'Phone Case', 'ACC20241227004', '', '1', '500.00', 500, 500, '500', 0, 'cash', 1, '1', '274680', 0, 0, 0, 0, 'Hamid SHah', '03220716197', '', 150, 'paid', 500, 0, '6', 0)
ERROR - 2025-12-28 06:18:45 --> Severity: Warning --> Undefined array key "pos_cart" C:\xampp\htdocs\mobile-shop-pos\application\libraries\Genlib.php 219
ERROR - 2025-12-28 06:18:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\mobile-shop-pos\application\libraries\Genlib.php 219
ERROR - 2025-12-28 06:19:11 --> Query error: Unknown column 'trade_in_value' in 'field list' - Invalid query: INSERT INTO `transactions` (transDate, `itemName`, `itemCode`, `description`, `quantity`, `unitPrice`, `totalPrice`, `totalMoneySpent`, `amountTendered`, `changeDue`, `modeOfPayment`, `transType`, `staffId`, `ref`, `vatAmount`, `vatPercentage`, `discount_amount`, `discount_percentage`, `cust_name`, `cust_phone`, `cust_email`, `profit_amount`, `payment_status`, `paid_amount`, `credit_amount`, `customer_id`, `trade_in_value`) VALUES (NOW(), 'Phone Case', 'ACC20241227004', '', '1', '500.00', 500, 500, 0, 0, 'credit', 1, '1', '27102956', 0, 0, 0, 0, 'Hamid SHah', '03220716197', '', 150, 'credit', 0, 500, '6', 0)
ERROR - 2025-12-28 06:19:22 --> Query error: Unknown column 'trade_in_value' in 'field list' - Invalid query: INSERT INTO `transactions` (transDate, `itemName`, `itemCode`, `description`, `quantity`, `unitPrice`, `totalPrice`, `totalMoneySpent`, `amountTendered`, `changeDue`, `modeOfPayment`, `transType`, `staffId`, `ref`, `vatAmount`, `vatPercentage`, `discount_amount`, `discount_percentage`, `cust_name`, `cust_phone`, `cust_email`, `profit_amount`, `payment_status`, `paid_amount`, `credit_amount`, `customer_id`, `trade_in_value`) VALUES (NOW(), 'Phone Case', 'ACC20241227004', '', '1', '500.00', 500, 500, '500', 0, 'cash', 1, '1', '081472', 0, 0, 0, 0, 'Hamid SHah', '03220716197', '', 150, 'paid', 500, 0, '6', 0)
ERROR - 2025-12-28 06:23:42 --> Query error: Unknown column 'trade_in_value' in 'field list' - Invalid query: INSERT INTO `transactions` (transDate, `itemName`, `itemCode`, `description`, `quantity`, `unitPrice`, `totalPrice`, `totalMoneySpent`, `amountTendered`, `changeDue`, `modeOfPayment`, `transType`, `staffId`, `ref`, `vatAmount`, `vatPercentage`, `discount_amount`, `discount_percentage`, `cust_name`, `cust_phone`, `cust_email`, `profit_amount`, `payment_status`, `paid_amount`, `credit_amount`, `customer_id`, `trade_in_value`) VALUES (NOW(), 'Phone Case', 'ACC20241227004', '', '1', '500.00', 500, 500, '500', 0, 'cash', 1, '1', '7942798', 0, 0, 0, 0, 'Hamid SHah', '03220716197', '', 150, 'paid', 500, 0, '6', 0)
ERROR - 2025-12-28 06:24:03 --> Query error: Unknown column 'trade_in_value' in 'field list' - Invalid query: INSERT INTO `transactions` (transDate, `itemName`, `itemCode`, `description`, `quantity`, `unitPrice`, `totalPrice`, `totalMoneySpent`, `amountTendered`, `changeDue`, `modeOfPayment`, `transType`, `staffId`, `ref`, `vatAmount`, `vatPercentage`, `discount_amount`, `discount_percentage`, `cust_name`, `cust_phone`, `cust_email`, `profit_amount`, `payment_status`, `paid_amount`, `credit_amount`, `customer_id`, `trade_in_value`) VALUES (NOW(), 'Phone Case', 'ACC20241227004', '', '1', '500.00', 500, 500, '500', 0, 'cash', 1, '1', '6976921', 0, 0, 0, 0, 'Hamid SHah', '03220716197', '', 150, 'paid', 500, 0, '6', 0)
ERROR - 2025-12-28 07:54:31 --> Severity: Warning --> Undefined array key "pos_cart" C:\xampp\htdocs\mobile-shop-pos\application\libraries\Genlib.php 219
ERROR - 2025-12-28 07:54:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\mobile-shop-pos\application\libraries\Genlib.php 219
ERROR - 2025-12-28 07:54:51 --> Query error: Unknown column 'staffInCharge' in 'field list' - Invalid query: INSERT INTO `eventlog` (`event`, `eventRowIdOrRef`, `eventDesc`, `eventTable`, `staffInCharge`) VALUES ('New Transaction', '61592409', '1 items totalling ₨500.00 with reference 61592409', 'transactions', '1')
ERROR - 2025-12-28 12:42:09 --> Query error: Unknown column 'staffInCharge' in 'field list' - Invalid query: INSERT INTO `eventlog` (`event`, `eventRowIdOrRef`, `eventDesc`, `eventTable`, `staffInCharge`) VALUES ('New Transaction', '581985', '1 items totalling ₨2,500.00 with reference 581985', 'transactions', '1')
ERROR - 2025-12-28 12:42:51 --> Query error: Unknown column 'staffInCharge' in 'field list' - Invalid query: INSERT INTO `eventlog` (`event`, `eventRowIdOrRef`, `eventDesc`, `eventTable`, `staffInCharge`) VALUES ('New Transaction', '93577289', '1 items totalling ₨500.00 with reference 93577289', 'transactions', '1')
ERROR - 2025-12-28 13:14:01 --> 404 Page Not Found: Transactions/receipt
ERROR - 2025-12-28 13:30:49 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`mobile_shop_pos`.`transactions`, CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL) - Invalid query: INSERT INTO `transactions` (transDate, `itemName`, `itemCode`, `description`, `quantity`, `unitPrice`, `totalPrice`, `totalMoneySpent`, `amountTendered`, `changeDue`, `modeOfPayment`, `payment_status`, `paid_amount`, `credit_amount`, `transType`, `staffId`, `ref`, `vatAmount`, `vatPercentage`, `discount_amount`, `discount_percentage`, `profit_amount`, `cust_name`, `cust_phone`, `cust_email`, `customer_id`, `trade_in_value`, `imei_numbers`) VALUES (NOW(), 'Phone Case', 'ACC20241227004', '', '1', '500.00', 500, 500, '500', 0, 'cash', 'paid', 500, 0, 1, '1', '041890', 0, 0, 0, 0, 150, '', '', '', '', 0, NULL)
ERROR - 2025-12-28 13:30:56 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mobile-shop-pos\application\controllers\Dashboard.php 170
ERROR - 2025-12-28 13:30:56 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mobile-shop-pos\application\controllers\Dashboard.php 170
ERROR - 2025-12-28 13:30:57 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mobile-shop-pos\application\controllers\Dashboard.php 170
ERROR - 2025-12-28 13:31:33 --> 404 Page Not Found: Transactions/receipt
ERROR - 2025-12-28 14:06:21 --> Severity: Warning --> Undefined array key "pos_cart" C:\xampp\htdocs\mobile-shop-pos\application\libraries\Genlib.php 219
ERROR - 2025-12-28 14:06:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\mobile-shop-pos\application\libraries\Genlib.php 219
ERROR - 2025-12-28 14:06:39 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mobile-shop-pos\application\controllers\Dashboard.php 170
ERROR - 2025-12-28 14:06:44 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mobile-shop-pos\application\controllers\Dashboard.php 170
ERROR - 2025-12-28 14:06:53 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mobile-shop-pos\application\controllers\Dashboard.php 170
ERROR - 2025-12-28 14:06:53 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mobile-shop-pos\application\controllers\Dashboard.php 170
ERROR - 2025-12-28 22:16:12 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mobile-shop-pos\application\controllers\Dashboard.php 170
ERROR - 2025-12-28 23:32:08 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mobile-shop-pos\application\controllers\Dashboard.php 170
ERROR - 2025-12-28 23:35:14 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mobile-shop-pos\application\controllers\Dashboard.php 170
