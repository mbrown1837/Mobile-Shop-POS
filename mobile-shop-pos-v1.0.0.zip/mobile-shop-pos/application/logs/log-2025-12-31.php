<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-31 02:17:48 --> Severity: Warning --> Undefined property: stdClass::$transaction_ref C:\xampp\htdocs\mobile-shop-pos\application\views\customers\ledger.php 130
ERROR - 2025-12-31 02:17:48 --> Severity: Warning --> Undefined property: stdClass::$balance_after C:\xampp\htdocs\mobile-shop-pos\application\views\customers\ledger.php 143
ERROR - 2025-12-31 02:17:48 --> Severity: Warning --> Undefined property: stdClass::$transaction_ref C:\xampp\htdocs\mobile-shop-pos\application\views\customers\ledger.php 130
ERROR - 2025-12-31 02:17:48 --> Severity: Warning --> Undefined property: stdClass::$balance_after C:\xampp\htdocs\mobile-shop-pos\application\views\customers\ledger.php 143
ERROR - 2025-12-31 02:18:03 --> Severity: Warning --> Undefined property: stdClass::$transaction_ref C:\xampp\htdocs\mobile-shop-pos\application\views\customers\ledger.php 130
ERROR - 2025-12-31 02:18:03 --> Severity: Warning --> Undefined property: stdClass::$balance_after C:\xampp\htdocs\mobile-shop-pos\application\views\customers\ledger.php 143
ERROR - 2025-12-31 02:18:03 --> Severity: Warning --> Undefined property: stdClass::$transaction_ref C:\xampp\htdocs\mobile-shop-pos\application\views\customers\ledger.php 130
ERROR - 2025-12-31 02:18:03 --> Severity: Warning --> Undefined property: stdClass::$balance_after C:\xampp\htdocs\mobile-shop-pos\application\views\customers\ledger.php 143
ERROR - 2025-12-31 02:18:03 --> Severity: Warning --> Undefined property: stdClass::$transaction_ref C:\xampp\htdocs\mobile-shop-pos\application\views\customers\ledger.php 130
ERROR - 2025-12-31 02:18:03 --> Severity: Warning --> Undefined property: stdClass::$balance_after C:\xampp\htdocs\mobile-shop-pos\application\views\customers\ledger.php 143
ERROR - 2025-12-31 02:34:44 --> Severity: Warning --> Undefined property: stdClass::$transaction_ref C:\xampp\htdocs\mobile-shop-pos\application\views\customers\ledger.php 130
ERROR - 2025-12-31 02:34:44 --> Severity: Warning --> Undefined property: stdClass::$balance_after C:\xampp\htdocs\mobile-shop-pos\application\views\customers\ledger.php 143
ERROR - 2025-12-31 02:34:44 --> Severity: Warning --> Undefined property: stdClass::$transaction_ref C:\xampp\htdocs\mobile-shop-pos\application\views\customers\ledger.php 130
ERROR - 2025-12-31 02:34:44 --> Severity: Warning --> Undefined property: stdClass::$balance_after C:\xampp\htdocs\mobile-shop-pos\application\views\customers\ledger.php 143
ERROR - 2025-12-31 03:53:33 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mobile-shop-pos\application\controllers\Administrators.php 59
ERROR - 2025-12-31 03:57:30 --> 404 Page Not Found: Reports/imeiStatus
ERROR - 2025-12-31 04:06:52 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mobile-shop-pos\application\controllers\Administrators.php 59
